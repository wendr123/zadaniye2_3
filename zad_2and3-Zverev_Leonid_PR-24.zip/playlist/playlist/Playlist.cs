﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace playlist
{
    internal class Playlist
    {
        public List<Song> playlist;
        public int currentIndex = 0;

        public Playlist()
        {
            playlist = new List<Song>();
            currentIndex = 0;
        }

        public Song currentSong()
        {
            if (playlist.Count > 0)
            {
                return playlist[currentIndex];
            }
            else
            {
                throw new IndexOutOfRangeException("Невозможно получить текущую аудиозапись для пустого плейлиста!");
            }
        }

        public void addSong(Song song)
        {
            playlist.Add(song);
        }

        public void addSong(string title, string author, string fileName)
        {
            Song song = new Song();

            song.Title = title;
            song.Author = author;
            song.FileName = fileName;

            playlist.Insert(0, song);
        }

        public void nextSong()
        {
            if (currentIndex < playlist.Count - 1)
            {
                currentIndex++;
            }
        }

        public void previousSong()
        {
            if (currentIndex > 0)
            {
                currentIndex--;
            }
        }

        public void clearPlaylist()
        {
            playlist.Clear();
        }

        public void deleteSong()
        {
            playlist.RemoveAt(currentIndex);
        }

        public void deleteSong(int firstIndex, int lastIndex)
        {
            if (firstIndex < lastIndex && firstIndex < playlist.Count && lastIndex < playlist.Count)
            {
                playlist.RemoveRange(firstIndex, lastIndex);
            }
            else
            {
                Console.WriteLine("Введите правильные значения для удаления песен!");
            }
        }

        public void chooseSong()
        {
            currentIndex = 3;
        }

        public void getInfoAboutSong(int songNumber)
        {
            if (songNumber <= playlist.Count && songNumber >= 0)
            {
                Console.WriteLine($"Название: {playlist[songNumber].Title}. Автор: {playlist[songNumber].Author}. Путь к файлу: {playlist[songNumber].FileName}.");
            }
            else
            {
                Console.WriteLine("Введите правильный номер песни");
            }
        }

        public void getInfoAboutSongs()
        {
            if (playlist.Count > 0)
            {
                foreach (var song in playlist)
                {
                    Console.WriteLine($"Название: {song.Title}. Автор: {song.Author}. Путь к файлу: {song.FileName}.");
                }
            }
            else
            {
                Console.WriteLine("Ваш плейлист пуст");
            }

        }
    }
}

